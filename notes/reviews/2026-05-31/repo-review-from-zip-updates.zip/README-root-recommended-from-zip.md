# Imperial AI Coursework

Preparation workspace for the Imperial College Business School Professional Certificate in Machine Learning and Artificial Intelligence.

This repository contains my own preparation notes, notebooks, experiments and supporting tools. It is not intended to publish assessed submission material or copyrighted course materials.

## Purpose

The repo is used for:

- refreshing linear algebra, calculus, probability and statistics
- practising Python, NumPy, pandas, scikit-learn and notebook workflows
- building small worked examples that connect mathematical ideas to machine learning
- keeping course preparation notes, environment checks and public learning resources in one place

## Current focus

The current active focus is finishing the `maths-refresh/` sequence and then moving into `ml-foundations/`.

The maths refresh path now runs from vectors through design matrices and model prediction:

- vectors, shapes and norms
- dot products and cosine similarity
- projections and components
- matrices as 2D transformations
- transforming shapes with matrices
- introductory least squares
- least squares as projection
- design matrices and model prediction

The next stage belongs in `ml-foundations/`, where model fitting ideas such as loss functions, gradient descent, and generalisation can be developed without overloading the maths-refresh sequence.

## Repository structure

```text
imperial-ai-coursework/
  course-labs/      Course-style labs and environment checks.
  maths-refresh/    Pre-course maths notebooks and small interactive tools.
  ml-foundations/   Early machine-learning notebooks that build on the maths refresh.
  notebooks/        Broader structured module-aligned notebooks for later course topics.
  notes/            Setup notes, cheatsheets, module maps and resource indexes.
  scratch/          Temporary experiments and exploratory notebooks.
```

## Key areas

### `maths-refresh/`

Bite-sized notebooks for rebuilding the mathematical intuition needed before the course. These are deliberately practical, using small Python and NumPy examples rather than trying to be a formal textbook.

This area is mainly for pre-course foundations and visual intuition. It should not grow into the full machine-learning curriculum.

The matrix transformation notebooks are supported by a small browser-based interactive tool in `maths-refresh/interactive/`.

### `ml-foundations/`

Early machine-learning notebooks that build directly on the maths refresh.

This is the right place for topics such as:

- linear regression from scratch
- loss functions
- gradient descent
- train/test split and generalisation
- simple model evaluation

### `notebooks/`

A broader structured area for module-aligned notebooks covering course topics over time. This is separate from `maths-refresh/`, which is more focused on pre-course foundations, and from `ml-foundations/`, which is the immediate bridge into model fitting.

### `notes/`

Supporting reference material, including setup notes, cheatsheets, course/module mapping and public resource tracking.

### `scratch/`

Disposable experiments. Content here may be incomplete, untidy or superseded.

## Working style

The emphasis is on clear, reproducible learning artefacts:

- plain-English explanations
- small hand-checkable examples
- Python / NumPy / pandas implementation
- simple visuals where they help
- short notes on why the concept matters for machine learning

## Status

This is an active learning repository. Some folders are more complete than others, and the structure will continue to evolve as the course preparation moves from maths refresh into broader machine learning topics.
