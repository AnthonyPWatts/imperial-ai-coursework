# Review of supplied zip: maths-helper sequence

## Verdict

The zip is a better source of truth than the public GitHub page. In this version, `08-design-matrices-and-model-predictions.ipynb` exists and is far enough along to count as the end of the maths-refresh bridge.

I would now treat `01` through `08` as the stable maths-refresh path, subject only to small wording polish in `08`.

## Sequence review

The learning path now has a coherent shape:

1. `01` — vectors, array shapes, norms
2. `02` — dot products and cosine similarity
3. `03` — projections and components
4. `04`/`04a`-`04d` — matrices as transformations
5. `05` — applying matrices to whole shapes
6. `06` — least squares from line fitting
7. `07` — least squares as projection
8. `08` — design matrices and model prediction

That is a clean progression from geometry to matrix notation to the earliest ML model-fitting notation.

## `08` review

`08` is doing the right job. It connects the familiar line equation to:

```text
y_hat = X @ beta
```

and it explains rows, columns, parameters, predictions, residuals, and shape checks.

I executed `08-design-matrices-and-model-predictions.ipynb` successfully in the sandbox.

Minor polish still recommended:

- Replace the remaining “input data” phrasing with something like “prepared feature values” or “the prediction-side values”.
- In the opening, avoid letting the wording suggest “training data goes into the model”. The notebook is mainly about consuming/evaluating points to make predictions.
- The current residuals preview is fine, but stop there. Loss functions should be the next stage, not expanded inside `08`.

## Topic drift

`09-loss-functions.ipynb`, `10-gradients.ipynb`, and `11-gradient-descent-by-hand.ipynb` are useful topics, but they are no longer really maths-refresh material.

They overlap naturally with `ml-foundations/`, especially:

- `01-linear-regression-from-scratch.ipynb`
- `02-linear-regression-with-gradient-descent.ipynb`
- `03-train-test-split-and-generalisation.ipynb`

Recommendation:

- Do not build `09`-`11` as normal maths-refresh notebooks.
- Move or recreate those ideas under `ml-foundations/`.
- Let maths-refresh finish at `08`, with the README explicitly saying that the next stage is `ml-foundations/`.

## README changes

The root README needs to mention `ml-foundations/`, because it exists in the zip and is the natural next active area.

The maths-refresh README should be updated from “reviewed foundation currently runs from `01` through `07`” to “now runs from `01` through `08`”.

The maths-refresh README should also explicitly mark loss functions, gradients, and gradient descent as boundary topics that belong in `ml-foundations/`.

## Repository hygiene

The zip contains two untracked PDF bank-statement-looking files under `maths-refresh/`:

- `Statement--560045-31283128--07-03-2026-08-04-2026.pdf`
- `Statement--560045-31283128--09-04-2026-08-05-2026.pdf`

They should be removed from the working tree and not committed.

I also recommend adding an ignore rule for `Statement--*.pdf` to reduce the chance of accidentally committing personal documents.

## Generated replacement files

- `README-root-recommended-from-zip.md` — replacement for root `README.md`
- `README-maths-refresh-recommended-from-zip.md` — replacement for `maths-refresh/README.md`
- `gitignore-recommended-from-zip.txt` — suggested `.gitignore` contents
